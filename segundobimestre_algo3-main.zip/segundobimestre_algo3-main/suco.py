def suco_laranja(laranja):
    #processamento
    return "suco de laranja pronto"
resultado=suco_laranja("laranja pêra")
print(resultado)